/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugaspraktikumpbo;

/**
 *
 * @author User
 */
public class Tugaspraktikumpbo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /* instansiasi*/
        /*ukuran satuan cm*/
     keramik k1 = new keramik();
     k1.ukuran = 30*30;
     k1.box = 10;
     k1.rupiah = 54000;
     k1.hitungJumlah ();
     k1.jumlahKerdus ();
     k1.totalHarga();
     
     keramik k2 = new keramik();
     k2.ukuran = 40*40;
     k2.box = 5;
     k2.rupiah = 65000;
     k2.hitungJumlah ();
     k2.jumlahKerdus ();
     k2.totalHarga ();
     
     keramik k3 = new keramik ();
     k3.ukuran = 30*40;
     k3.box = 8;
     k3.rupiah = 60000;
     k3.hitungJumlah ();
     k3.jumlahKerdus ();
     k3.totalHarga ();
     
    }
    
}
